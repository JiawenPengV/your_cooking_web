from django.apps import AppConfig


class GrumblrConfig(AppConfig):
    name = 'grumblr'
